package com.caixaeletronicoatm.controller;

import java.util.Calendar;
import java.net.URI;
import java.util.ArrayList;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.caixaeletronicoatm.model.Conta;
import com.caixaeletronicoatm.model.Saque;
import com.caixaeletronicoatm.model.User;
import com.caixaeletronicoatm.model.dao.ContaDAO;
import com.caixaeletronicoatm.model.dao.SaqueDAO;
import com.caixaeletronicoatm.model.dao.UserDAO;

@RestController
@ResponseBody
@RequestMapping("/saque")
public class SaqueController {
	
	private Calendar dataAtual = Calendar.getInstance();
	//ArrayList<Saque> saques = new ArrayList<Saque>();
	private SaqueDAO sqd = new SaqueDAO();
	private Saque sq = new Saque();
	
	private ContaDAO accd = new ContaDAO();
	private Conta acc = new Conta();
	
	
	/*@GetMapping
	public ArrayList<Saque> allSaque(){
		saques = sqd.getSaques();
		return saques; 
	}
	
	@GetMapping("/valorConta")
	public int valorTotalConta(){
		sq = sqd.Conta();
		int valorTotal = sq.getSaldoTotal();
		return valorTotal;
	}
	
	@GetMapping("/numeroConta")
	public int numeroConta() {
		sq = sqd.Conta();
		int nConta = sq.getNumeroConta();
		return nConta;
	}
	
	@GetMapping("/sacar")
	public int quantidadeSaque(@RequestParam(value = "quantidadeSaque", required = true, defaultValue = "1")Integer qtdSaque, 
			@RequestParam(value = "numeroConta", required = true, defaultValue = "1")Integer nConta) {
		Saque sq = new Saque();
		User us = new User();
		us = sqd.getnumeroConta(nConta);
		acc = accd.getConta(nConta);
		
		sq.setQntdSaque(qtdSaque);
		sq.setSaldoDisponivel(acc.getSaldoDisponivel());
		sq.setNumeroConta(us.getNumeroConta());
		sq.setSaldoTotal(us.getSaldoTotal());
		
		int valorTotal = sq.getSaldoTotal();
		if(qtdSaque < valorTotal) {
			int resultado = valorTotal - qtdSaque;
			acc = accd.getConta(nConta);
			acc.setSaldoDisponivel(resultado);
			return 1;
		}
		return 0;
	}*/
	
	@GetMapping("/totalConta")
	public int totalConta() {
		
		acc = accd.getConta(1111);
		acc.getSaldoDisponivel();
		
		return acc.getSaldoDisponivel();
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(value = "/sacar")
	public int sacar(@RequestBody Saque qntdValorSaque) {
		Saque saque = new Saque();
		acc = accd.getConta(qntdValorSaque.getNumeroConta());
		
		saque.setQntdSaque(qntdValorSaque.getQntdSaque());
		saque.setSaldoDisponivel(acc.getSaldoDisponivel());
		saque.setNumeroConta(qntdValorSaque.getNumeroConta());
		saque.setSaldoTotal(qntdValorSaque.getSaldoTotal());
		
		int valorSaque = saque.getQntdSaque();
		int valorTotal = saque.getSaldoDisponivel();
		if(valorSaque < valorTotal) {
			int resultado = valorTotal - valorSaque;
			acc.setSaldoDisponivel(resultado);
			sq.setQntdSaque(valorSaque);
			sq.setSaldoDisponivel(resultado);
			return acc.getSaldoDisponivel();
		}
		return 0;
	}

}
