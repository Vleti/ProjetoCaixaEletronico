package com.caixaeletronicoatm.controller;

import java.util.Calendar;
import java.net.URI;
import java.util.ArrayList;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.caixaeletronicoatm.model.User;
import com.caixaeletronicoatm.model.dao.UserDAO;

@RestController
@ResponseBody
@RequestMapping("/usuario")
public class UsuarioController {
	
	ArrayList<User> users = new ArrayList<User>();
	private UserDAO usDao= new UserDAO();
	private User us = new User();
	
	@GetMapping
	public ArrayList<User> allUsers(){
		ArrayList<User> usuarios = null;
		usuarios = usDao.getUsers();
		return usuarios;
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@GetMapping("/validacao")
	public User validacaoUsuario(@RequestParam(value = "nome", required = true, defaultValue = "um")String nome, @RequestParam(value = "senha", required = false, defaultValue = "1")Integer senha) {
		User us = new User();
		us = usDao.validaUsuario(nome, senha);
		if(us!=null) {
			return us;
		}
		return null;	
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@GetMapping("/procuraUsu")
	public User findUsuario(@RequestParam(value = "numeroConta", required = true, defaultValue = "um")Integer nConta) {
		us = usDao.getnConta(nConta);
		if(us!=null) {
			return us;
		}
		return null;	
	}
}
	

