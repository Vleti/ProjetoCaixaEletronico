package com.caixaeletronicoatm.controller;

import java.util.Calendar;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.caixaeletronicoatm.model.Conta;
import com.caixaeletronicoatm.model.Extrato;
import com.caixaeletronicoatm.model.dao.ContaDAO;
import com.caixaeletronicoatm.model.dao.ExtratoDAO;

@RestController
@ResponseBody
@RequestMapping("/extratos")
public class ExtratoController {
	
	ArrayList<Extrato> extratos = new ArrayList<Extrato>();
	private ExtratoDAO extDao= new ExtratoDAO();
	private Extrato ext = new Extrato();
	private ContaDAO accd = new ContaDAO();
	private Conta acc = new Conta();
	
	private String dataAtual = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
	
	
	@GetMapping
	public ArrayList<Extrato> AllExtratos(){
		extratos = extDao.getAllExtratos();
		return extratos;
	}
	
	
	@GetMapping("/extrato")
	public Extrato getExtratosData(@RequestParam(value = "numeroConta", required = true, defaultValue = "1")Integer nConta){
		ext.setDataExtrato(dataAtual);
		ext.setSaque(1000);
		ext.setDeposito(200);
		acc = accd.getConta(nConta);
		ext.setSaldoDisponivel(acc.getSaldoDisponivel());
		ext.setNumeroConta(nConta);
		
		return ext; 
	}
}
