package com.caixaeletronicoatm.controller;

import java.nio.file.AccessDeniedException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.caixaeletronicoatm.model.Conta;
import com.caixaeletronicoatm.model.Deposito;
import com.caixaeletronicoatm.model.Extrato;
import com.caixaeletronicoatm.model.Saque;
import com.caixaeletronicoatm.model.dao.ContaDAO;

@RestController
@ResponseBody
@RequestMapping("/conta")
public class ContaController {
	
	private String dataAtual = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
	private ContaDAO accd = new ContaDAO();
	private Conta acc;
	ArrayList<Extrato> extratos = new ArrayList<Extrato>();
	Extrato ext = new Extrato();
	
	
	
	@GetMapping("/contaInf")
	public Conta conta(@RequestParam(value = "numeroConta", required = true, defaultValue = "um")Integer nConta){
		acc= accd.getConta(nConta);
		return acc; 
	}
	
	@PostMapping(value = "/sacar")
	public int sacar(@RequestBody Saque qntdValorSaque) {
		Saque saque = new Saque();
		acc = accd.getConta(qntdValorSaque.getNumeroConta());
		
		saque.setQntdSaque(qntdValorSaque.getQntdSaque());
		saque.setSaldoDisponivel(acc.getSaldoDisponivel());
		saque.setNumeroConta(qntdValorSaque.getNumeroConta());
		saque.setSaldoTotal(qntdValorSaque.getSaldoTotal());
		
		int valorSaque = saque.getQntdSaque();
		int valorTotal = saque.getSaldoDisponivel();
		if(valorSaque < valorTotal) {
			int resultado = valorTotal - valorSaque;
			acc.setSaldoDisponivel(resultado);
			saque.setQntdSaque(valorSaque);
			saque.setSaldoDisponivel(resultado);
			ext.setSaque(valorSaque);
			return 1;
		}
		return 0;
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(value = "/depositar")
	public int depositar(@RequestBody Deposito deposito) {
		Deposito dp = new Deposito();
		acc = accd.getConta(deposito.getNumeroConta());
		
		dp.setQuantidadeDep(deposito.getQuantidadeDep());
		dp.setNumeroConta(deposito.getNumeroConta());
		dp.setSaldoDisponivel(acc.getSaldoDisponivel());
		dp.setSaldoTotal(acc.getSaldoTotal());
		
		int valorDeposito = dp.getQuantidadeDep();
		int SaldoDisp = dp.getSaldoDisponivel();
		int SaldoAnterior = dp.getSaldoTotal();
		
		if(valorDeposito < SaldoAnterior*100) {
			int valorTotal = valorDeposito + SaldoDisp;
			acc.setSaldoDisponivel(valorTotal);
			acc.setSaldoTotal(valorTotal);
			dp.setQuantidadeDep(valorDeposito);
			dp.setSaldoDisponivel(SaldoDisp);
			ext.setDeposito(valorDeposito);
			return 1;
		}
		return 0;
	}
	
	@GetMapping("/extrato")
	public Extrato extrato(@RequestParam(value = "numeroConta", required = true, defaultValue = "um")Integer nConta){
		ext.setNumeroConta(nConta);
		ext.setDataExtrato(dataAtual);
		return ext; 
	}
	
}

