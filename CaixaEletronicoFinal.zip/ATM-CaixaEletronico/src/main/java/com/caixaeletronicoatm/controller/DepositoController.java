package com.caixaeletronicoatm.controller;

import java.util.Calendar;
import java.net.URI;
import java.util.ArrayList;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.caixaeletronicoatm.model.Conta;
import com.caixaeletronicoatm.model.Deposito;
import com.caixaeletronicoatm.model.Saque;
import com.caixaeletronicoatm.model.User;
import com.caixaeletronicoatm.model.dao.ContaDAO;
import com.caixaeletronicoatm.model.dao.DepositoDAO;
import com.caixaeletronicoatm.model.dao.UserDAO;

@RestController
@ResponseBody
@RequestMapping("/deposito")
public class DepositoController {
	
	private Deposito dep = new Deposito();
	
	private ContaDAO accd = new ContaDAO();
	private Conta acc;
	
	
	/*@GetMapping
	public ArrayList<Deposito> allDepositos(){
		depositos = depDao.getDepositos();
		return depositos; 
	}
	
	@GetMapping("/depositar")
	public int qntdDepositada(@RequestParam(value = "quantidadeDeposito", required = true, defaultValue = "1")Integer qtdDeposito, 
			@RequestParam(value = "numeroConta", required = true, defaultValue = "1")Integer nConta) {
		Deposito dp = new Deposito();
		User us = new User();
		us = depDao.getnumeroConta(nConta);
		
		dp.setQuantidadeDep(qtdDeposito);
		dp.setSaldoTotal(us.getSaldoDisponivel() + us.getSaldoTotal());
		dp.setNumeroConta(us.getNumeroConta());
		
		int valorTotal = dp.getSaldoTotal();
		int resultado = valorTotal + qtdDeposito;
		acc = accd.getConta(nConta);
		acc.setSaldoDisponivel(resultado);
		return 1;
	}*/
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(value = "/depositar")
	public int depositar(@RequestBody Deposito deposito) {
		Deposito dp = new Deposito();
		acc = accd.getConta(deposito.getNumeroConta());
		
		dp.setQuantidadeDep(deposito.getQuantidadeDep());
		dp.setNumeroConta(deposito.getNumeroConta());
		dp.setSaldoDisponivel(acc.getSaldoDisponivel());
		dp.setSaldoTotal(acc.getSaldoTotal());
		
		int qntdDep = dp.getQuantidadeDep();
		int SaldoDisp = dp.getSaldoDisponivel();
		int SaldoAnterior = dp.getSaldoTotal();
		if(qntdDep < SaldoAnterior*100) {
			int valorTotal = qntdDep + SaldoDisp;
			acc.setSaldoDisponivel(valorTotal);
			acc.setSaldoTotal(valorTotal);
			dep.setQuantidadeDep(qntdDep);
			dep.setSaldoDisponivel(SaldoDisp);
			
			return acc.getSaldoDisponivel();
		}
		return 0;
	}
}
