package com.caixaeletronicoatm;

public class DepositSlot {

	public boolean isEnvelopeReceived() {
		// TODO Auto-generated method stub
		return false;
	}

}
