package com.caixaeletronicoatm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtmCaixaEletronicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtmCaixaEletronicoApplication.class, args);
	}

}
