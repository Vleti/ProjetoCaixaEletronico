package com.caixaeletronicoatm.model.dao;

import java.util.ArrayList;

import com.caixaeletronicoatm.model.Conta;
import com.caixaeletronicoatm.model.Deposito;
import com.caixaeletronicoatm.model.Saque;

public class ContaDAO {

	private ArrayList<Conta> contas = new ArrayList<Conta>();
	
	public ContaDAO() {
		Conta acc1 = new Conta();
		Conta acc2 = new Conta();
		Conta acc3 = new Conta();
		
		acc1 = addInfConta1();
		acc2 = addInfConta2();
		acc3 = addInfConta3();
		
		contas.add(acc1);
		contas.add(acc2);
		contas.add(acc3);
		
		
	}
	
	public Conta addInfConta1() {
		Conta conta = new Conta();
		
		conta.setNumeroConta(1111);
		conta.setSaldoDisponivel(10000);
		conta.setSaldoTotal(10000);
		
		return conta;
	}
	
	public Conta addInfConta2() {
		Conta conta = new Conta();
		
		conta.setNumeroConta(2222);
		conta.setSaldoDisponivel(5000);
		conta.setSaldoTotal(5000);
		
		return conta;
	}
	
	public Conta addInfConta3() {
		Conta conta = new Conta();
		
		conta.setNumeroConta(3333);
		conta.setSaldoDisponivel(2343);
		conta.setSaldoTotal(2343);
		
		return conta;
	}
	
	public Conta getConta(int nConta) {
		for(Conta acc : contas) {
			if(acc.getNumeroConta()==nConta) {
				return acc;
			}
		}
		return null;
	}		


	public ArrayList<Conta> getContas() {
		if(contas.size()>0) {
			return contas;
		}
		return null;
	}
}



	

