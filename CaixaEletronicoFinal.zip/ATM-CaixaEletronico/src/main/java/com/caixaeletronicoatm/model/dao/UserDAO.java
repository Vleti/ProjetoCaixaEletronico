package com.caixaeletronicoatm.model.dao;
import java.util.ArrayList;

import com.caixaeletronicoatm.model.Conta;
import com.caixaeletronicoatm.model.User;

public class UserDAO {

	private ArrayList<User> users = new ArrayList<User>();
	
	//Pega os valores via post
	private String nome;
	private int rg;
	private int cpf;
	private int numeroConta;
	private int verificaCPF;
	private int contador;
	
	private ContaDAO contaDao = new ContaDAO();
	private Conta conta = new Conta();
	
	
	public UserDAO() {
		User usu1 = new User();
		User usu2 = new User();
		User usu3 = new User();
		usu1 = addUser();
		usu2 = addUser2();
		usu3 = addUser3();
		
		users.add(usu1);
		users.add(usu2);
		users.add(usu3);
		
	}
	
	public User addUser() {
		User us1 = new User();
		us1.setNome("Ronaldo");
		us1.setSenha(12353);
		us1.setCpf(123432176);
		us1.setRg(301258743);
		us1.setNumeroConta(contaDao.addInfConta1().getNumeroConta());
		us1.setSaldoDisponivel(contaDao.addInfConta1().getSaldoDisponivel());
		us1.setSaldoTotal(contaDao.addInfConta1().getSaldoTotal());
		return us1;
	}
	
	public User addUser2() {
		User us2 = new User();
		us2.setNome("Mario");
		us2.setSenha(19123);
		us2.setCpf(555654322);
		us2.setRg(192131245);
		us2.setNumeroConta(contaDao.addInfConta2().getNumeroConta());
		us2.setSaldoDisponivel(contaDao.addInfConta2().getSaldoDisponivel());
		us2.setSaldoTotal(contaDao.addInfConta2().getSaldoTotal());
		return us2;
	}
	
	public User addUser3() {
		User us3 = new User();
		us3.setNome("Luis");
		us3.setSenha(49502);
		us3.setCpf(278088530);
		us3.setRg(405749340);
		us3.setNumeroConta(contaDao.addInfConta3().getNumeroConta());
		us3.setSaldoDisponivel(contaDao.addInfConta3().getSaldoDisponivel());
		us3.setSaldoTotal(contaDao.addInfConta3().getSaldoTotal());
		return us3;
	}
	
	public ArrayList<User> getUsers(){
		if(users.size()>0) {
			return users;
		}
		return null;
	}
		
		
		//Verifica se o CPF ja esta cadastrado
	public User getnConta(int nConta) {
		for(User usu : users) {
			if(usu.getNumeroConta()==nConta) {
				return usu;//CPF ja esta cadastrado
			}
		}
		return null;//CPF n�o esta cadastrado		
	}
	
	public User validaUsuario(String nome, int senha) {
		for(User usu : users) {
			if(usu.getNome().equals(nome) && usu.getSenha()==senha) {
				return usu;
			}
		}
		return null;
	}
	
	public User validaSenha(int senha) {
		for(User usu : users) {
			if(usu.getSenha()==senha) {
				return usu;
			}
		}
		return null;
	}
	
	//Remove usuario pelo nome
	public String getNome(String nomeUsu) {
		for(User usu : users) {
			if(usu.getNome().equals(nome)) {
				users.remove(contador);
				return "Usuario removido com sucesso!";
			}
			contador++;	
		}
		return null;
	}
			
	
	
}
