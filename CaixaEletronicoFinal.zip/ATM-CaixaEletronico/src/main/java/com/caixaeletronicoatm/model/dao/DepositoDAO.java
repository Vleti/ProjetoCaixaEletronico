package com.caixaeletronicoatm.model.dao;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import com.caixaeletronicoatm.model.Deposito;
import com.caixaeletronicoatm.model.User;

public class DepositoDAO{
	
	private ArrayList<Deposito> depositos = new ArrayList<Deposito>();
	ArrayList<User> users;
	UserDAO user = new UserDAO();
	
	
	private int quantidadeDep;
	private int numeroConta;
	private int dinheiroConta;
	private int totalConta;
	private String dataDeposito = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
	
	public DepositoDAO() {
		Deposito dp = addDeposito();
		depositos.add(dp);
	}
	
	public Deposito addDeposito() {
		Deposito dp = new Deposito();
		User us = new User();
		us = getnumeroConta(1111);
		
		dp.setQuantidadeDep(1000);
		dp.setDataDep(dataDeposito);
		dp.setSaldoTotal(us.getSaldoDisponivel() + us.getSaldoTotal());
		dp.setNumeroConta(us.getNumeroConta());
		
		return dp;
	}
	
	
	public User getnumeroConta(int nConta) {
		users = user.getUsers();
		for(User us : users) {
			if(us.getNumeroConta()==nConta) {
				return us;
			}
		}
		return null;
	}
	
	//Informa todos depositos
	public ArrayList<Deposito> getDepositos() {
		if(depositos.size()>0) {
			return depositos;
		}
		return null;
	}
	
}
