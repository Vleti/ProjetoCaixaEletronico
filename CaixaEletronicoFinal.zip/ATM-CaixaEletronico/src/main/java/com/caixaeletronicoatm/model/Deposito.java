package com.caixaeletronicoatm.model;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Deposito extends Conta {
	
	private int quantidadeDep;
	private String dataDep = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
	
	
	public int getQuantidadeDep() {
		return quantidadeDep;
	}
	public void setQuantidadeDep(int quantidadeDep) {
		this.quantidadeDep = quantidadeDep;
	}
	public String getDataDep() {
		return dataDep;
	}
	public void setDataDep(String dataDep) {
		this.dataDep = dataDep;
	}
	
}
