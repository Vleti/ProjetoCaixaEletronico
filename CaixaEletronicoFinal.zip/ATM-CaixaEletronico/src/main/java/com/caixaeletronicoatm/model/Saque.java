package com.caixaeletronicoatm.model;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Saque extends Conta{
	
	private int qntdSaque;
	private String dataSaque = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
	
	public int getQntdSaque() {
		return qntdSaque;
	}
	public void setQntdSaque(int qntdSaque) {
		this.qntdSaque = qntdSaque;
	}
	public String getDataSaque() {
		return dataSaque;
	}
	public void setDataSaque(String dataSaque) {
		this.dataSaque = dataSaque;
	}
}
