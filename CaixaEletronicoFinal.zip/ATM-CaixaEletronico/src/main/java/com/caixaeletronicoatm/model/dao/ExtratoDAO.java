package com.caixaeletronicoatm.model.dao;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.xml.crypto.Data;

import com.caixaeletronicoatm.model.Conta;
import com.caixaeletronicoatm.model.Deposito;
import com.caixaeletronicoatm.model.Extrato;
import com.caixaeletronicoatm.model.Saque;
import com.caixaeletronicoatm.model.User;

public class ExtratoDAO {

	ArrayList<Extrato> extratos = new ArrayList<Extrato>();
	ArrayList<User> users;
	ArrayList<Saque> saques;
	ArrayList<Deposito> depositos;
	ArrayList<Conta> contas;
	
	private String dataAtual = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
	
	UserDAO userDao = new UserDAO();
	SaqueDAO saqueDao = new SaqueDAO();
	DepositoDAO depositoDao = new DepositoDAO();
	ContaDAO contaDao = new ContaDAO();
	
	private int qntdSaque;
	private int qntdDeposito;
	private int numeroConta;
	private int saldoDisponivel;
	
	
	public ExtratoDAO() {
		Extrato ext = new Extrato();
		//ext = addExtrato(dataAtual);
		extratos.add(ext);
	}
	
	public Extrato addExtrato(int nConta) {
		Extrato ext = new Extrato();
		Saque sq = new Saque();
		Deposito dep = new Deposito();
		User us = new User();
		Conta acc = new Conta();
		
		sq = getSaqueNaData(nConta);
		dep = getDepositoNaData(nConta);
		us = getnumeroConta(nConta);
		acc = getSaldoDisponivel(nConta);
		
		
		ext.setDataExtrato(dataAtual);
		ext.setSaque(sq.getQntdSaque());
		ext.setDeposito(dep.getQuantidadeDep());
		ext.setSaldoDisponivel(acc.getSaldoDisponivel());
		ext.setNumeroConta(us.getNumeroConta());
		
		return ext;
	}
	
	public User getnumeroConta(int nConta) {
		users = userDao.getUsers();
		for(User us : users) {
			if(us.getNumeroConta()==nConta) {
				return us;
			}
		}
		return null;
	}
	
	public Saque getSaqueNaData(int nConta) {
		saques = saqueDao.getSaques();
		for(Saque sq : saques) {
			if(sq.getNumeroConta()==nConta) {
				return sq;
			}
		}
		return null;
	}
	
	public Deposito getDepositoNaData(int nConta) {
		depositos = depositoDao.getDepositos();
		for(Deposito dep : depositos) {
			if(dep.getNumeroConta()==nConta) {
				return dep;
			}
		}
		return null;
	}
	
	public Conta getSaldoDisponivel(int nConta) {
		contas = contaDao.getContas();
		for(Conta acc : contas) {
			if(acc.getNumeroConta()==nConta) {
				return acc;
			}
		}
		return null;
	}
	
	public Extrato getExtratos(String data){
		for(Extrato ext : extratos) {
			if(ext.getDataExtrato()==data) {
				return ext;
			}
		}
		return null;
	}
	
	public ArrayList<Extrato> getAllExtratos(){
		if(extratos.size()>1) {
			return extratos;
		}
		return null;
	}
	
	
}

