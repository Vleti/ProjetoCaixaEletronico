package com.caixaeletronicoatm.model;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Extrato extends Conta{
	
	private int saque;
	private int deposito;
	private String dataExtrato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
	
	public int getSaque() {
		return saque;
	}
	public void setSaque(int saque) {
		this.saque = saque;
	}
	public int getDeposito() {
		return deposito;
	}
	public void setDeposito(int deposito) {
		this.deposito = deposito;
	}
	public String getDataExtrato() {
		return dataExtrato;
	}
	public void setDataExtrato(String data) {
		this.dataExtrato = data;
	}	

}

