package com.caixaeletronicoatm.model;

public class Conta {
	
	private int saldoDisponivel; // saldo para saque
	private int numeroConta;
	private int saldoTotal;// saldo + deposito
	
	public int getSaldoDisponivel() {
		return saldoDisponivel;
	}
	public void setSaldoDisponivel(int saldoDisponivel) {
		this.saldoDisponivel = saldoDisponivel;
	}
	public int getNumeroConta() {
		return numeroConta;
	}
	public void setNumeroConta(int numeroConta) {
		this.numeroConta = numeroConta;
	}
	public int getSaldoTotal() {
		return saldoTotal;
	}
	public void setSaldoTotal(int saldoTotal) {
		this.saldoTotal = saldoTotal;
	}
	
	
	
	
}
