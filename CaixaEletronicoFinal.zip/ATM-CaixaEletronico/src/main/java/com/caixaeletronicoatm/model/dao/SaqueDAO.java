package com.caixaeletronicoatm.model.dao;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import com.caixaeletronicoatm.model.Saque;
import com.caixaeletronicoatm.model.User;

public class SaqueDAO{
	
	private ArrayList<Saque> saques = new ArrayList<Saque>();
	ArrayList<User> users;
	UserDAO userDAO = new UserDAO();
	
	private int saque;
	private int totalConta;
	private String dataAtual = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
	
	private int numeroConta;
	private User us;
	
	

	public SaqueDAO() {
		//numeroConta = us.getNumeroConta();
		Saque sq = new Saque();
		sq = Conta();
		saques.add(sq);
	}
	
	//Verifica o saque na data informada
	public Saque getData(String data) {
		for(Saque saq : saques) {
			if(saq.getDataSaque()==data) {
				return saq;
			}
		}
		return null;
	}
	//Informa todos saques
	public ArrayList<Saque> getSaques() {
		if(saques.size()>0) {
			return saques;
		}
		return null;
	}
	
	public Saque Conta(){
		Saque sq = new Saque();
		User us = new User();
		us = getnumeroConta(1111);
		
		sq.setDataSaque(dataAtual);	
		sq.setSaldoDisponivel(us.getSaldoDisponivel());
		sq.setNumeroConta(us.getNumeroConta());
		sq.setSaldoTotal(us.getSaldoTotal());
		
		return sq;
	}
	
	public User getnumeroConta(int nConta) {
		users = userDAO.getUsers();
		for(User us : users) {
			if(us.getNumeroConta()==nConta) {
				return us;
			}
		}
		return null;
	}
}
