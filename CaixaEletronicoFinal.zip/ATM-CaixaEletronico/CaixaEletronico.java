package com.caixaeletronicoatm.controller;

import java.util.Calendar;
import java.net.URI;
import java.util.ArrayList;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.caixaeletronicoatm.model.Conta;
import com.caixaeletronicoatm.model.Deposito;
import com.caixaeletronicoatm.model.User;
import com.caixaeletronicoatm.model.dao.ContaDAO;
import com.caixaeletronicoatm.model.dao.DepositoDAO;
import com.caixaeletronicoatm.model.dao.UserDAO;

@RestController
@ResponseBody
@RequestMapping("/depositos")
public class DepositoController {
	
	ArrayList<Deposito> depositos = new ArrayList<Deposito>();
	private DepositoDAO depDao= new DepositoDAO();
	private Deposito dep = new Deposito();
	private User us = new User();
	private UserDAO usDao = new UserDAO();
	
	private ContaDAO accd = new ContaDAO();
	private Conta acc = new Conta();
	
	@GetMapping
	public ArrayList<Deposito> allDepositos(){
		depositos = depDao.getDepositos();
		return depositos; 
	}
	
	@GetMapping("/quantidadeDeposito")
	public int qntdDepositada() {
		dep = depDao.addDeposito();
		int qntDep = dep.getQuantidadeDep();
		int totalDisp = dep.getSaldoTotal();
		us = usDao.validaSenha(12353);
		if(us!=null) {
			int total = totalDisp + qntDep;
			acc = accd.getConta(1111);
			acc.setSaldoDisponivel(total);
			return 1;
		}
		
		return 0;
	}
}
