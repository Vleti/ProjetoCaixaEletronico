const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const nConta = urlParams.get('numeroConta');


function fazGet(url){
    let request = new XMLHttpRequest();
    request.open("GET", url, false);
    request.send();
    return request.responseText;
}

function main(){
    let url = "http://localhost:8080/conta/contaInf?numeroConta="+nConta;
    let data = fazGet(url);
    const conta = JSON.parse(data);
    document.getElementById("saldo").innerHTML = conta.saldoDisponivel;
}
main();

function fazPost(urlS,body){
    let request = new XMLHttpRequest();
    request.open("POST", urlS, true);
    request.setRequestHeader("Content-type","application/json")
    request.send(body);
    return request.responseText;
}

function saque(){
    event.preventDefault();
    let saque = document.getElementById("valor").value;
    let urlSaque = "http://localhost:8080/conta/sacar;
    body = {
        "qntdSaque":saque,
		"numeroConta":nConta
    }
    let resultado = fazPost(urlSaque,body);
    
    if(resultado == 1){
        window.alert("Saque efetuado\nR$ "+saque);
        window.location.href = "http://10.107.74.22:5500/principal.html?numeroConta="+nConta+"&quantidadeSacada="+saque;
    }
    else{
        window.alert("Saque não efetuado com sucesso!");
    }
}

function voltar(){
    let url = "http://10.107.74.22:5500/principal.html?numeroConta="+nConta;
    window.location.replace(url);
}