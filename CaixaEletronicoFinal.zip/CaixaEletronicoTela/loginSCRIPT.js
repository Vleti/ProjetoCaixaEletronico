function fazGet(url){
    let request = new XMLHttpRequest();
    request.open("GET", url, false);
    request.send();
    return request.responseText;
}

function logar(){
    event.preventDefault();
    let nome = document.getElementById("nome").value;
    let senha = document.getElementById("senha").value;
    let url = "http://localhost:8080/usuario/validacao?nome="+nome+"&senha="+senha;
    let data = fazGet(url);
    var usuario = JSON.parse(data);
    if(usuario == null){
        window.alert("Usuário Incorreto");
    }
    else{
        window.location.href = "http://10.107.74.22:5500/principal.html?numeroConta="+usuario.numeroConta;
    }
}