const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const nConta = urlParams.get('numeroConta');
console.log(nConta);

function fazGet(url){
    let request = new XMLHttpRequest();
    request.open("GET", url, false);
    request.send();
    return request.responseText;
}

function main(){
    let url = "http://localhost:8080/conta/contaInf?numeroConta="+nConta;
    let data = fazGet(url);
    const conta = JSON.parse(data);
    document.getElementById("saldo3").innerHTML = conta.saldoDisponivel;
}
main();

function extrato(){
    let url = "http://localhost:8080/conta/extrato?numeroConta="+nConta;
    let resultado = fazGet(url);
    const extrato = JSON.parse(resultado);
    document.getElementById("extrat").innerHTML = 'Data Extrato:'+extrato.dataExtrato;
    document.getElementById("saq").innerHTML = 'Saque: '+extrato.saque;
    document.getElementById("dep").innerHTML = 'Deposito: '+extrato.deposito;
}
extrato();

function voltar(){
    let url = "http://10.107.74.22:5500/principal.html?numeroConta="+nConta;
    window.location.replace(url);
}